# SehatSaathi Flask + MongoDB Atlas

This version stores users, health camps, and registrations in MongoDB Atlas (collections: `users`, `camps`, `registrations`, and `counters`). The existing frontend remains in `templates/` and `static/`.

## Windows setup

1. Create/activate a virtual environment:
   ```powershell
   python -m venv .venv
   .\.venv\Scripts\Activate.ps1
   ```
2. Install dependencies:
   ```powershell
   python -m pip install -r requirements.txt
   ```
3. Create `.env` from `.env.example` if you don't already have one, then put your Atlas URI in `MONGODB_URI`. Keep `.env` private and do not commit it.
4. In Atlas, create a database user and allow your current IP address in Network Access.
5. Start the app:
   ```powershell
   python app.py
   ```
6. Open http://127.0.0.1:5000. The `/api/health` endpoint confirms the API is running.

The app checks the Atlas connection on startup. Sample camps are inserted into the database the first time if sample camps are not already present.

## API

- `GET /api/health`, `GET /api/services`
- `POST /api/auth/signup`, `POST /api/auth/login`, `GET /api/auth/me`
- `GET /api/profile`, `PUT /api/profile`, `DELETE /api/profile` (account deletion requires the current password)
- `PUT /api/profile/password`, `POST /api/profile/photo` (JPG/PNG/WebP, up to 2 MB)
- `GET /api/camps`, `GET /api/camps/<id>`, `POST/PUT/DELETE /api/camps/<id>` (creation/edit/deletion requires organizer token)
- `GET /api/registrations`, `POST /api/camps/<id>/registrations`, `DELETE /api/registrations/<id>`
- `GET /api/organizer/dashboard`, `GET /api/organizer/camps/<id>/participants.csv` (owner-only CSV export)
- `POST /api/suggestions`, `POST /api/chat`

### AI-personalized camp recommendations
`POST /api/suggestions` first computes safe, database-backed options from the selected age/gender/health-category checkboxes and upcoming camps. When `GEMINI_API_KEY` is configured, Gemini ranks those existing options and may personalize their short explanations; it cannot create or change camp records. If Gemini is unavailable, the endpoint automatically returns the existing rules-based recommendations. The response includes `ai_personalized` and `recommendation_source` so the frontend can show which path was used. Urgent symptoms bypass recommendations and show emergency guidance. The recommendation dialog discloses that selected profile categories are sent to Google AI when enabled; do not submit identifying details.

Signup/login passwords are stored as password hashes, not plain text. This MongoDB version starts a fresh set of collections; data in the old SQLite database is not automatically copied over.


## Organizer dashboard

1. Start Flask with `python app.py` and open `http://127.0.0.1:5000`.
2. Sign in using an account created with the **Camp organizer** role.
3. Select **Dashboard** in the top navigation, or use **Organizer log in** at the bottom of the home page.
4. Use **Add camp** to create a camp. Your camps appear under **Manage camps**. Use **Edit** to change details, **View** to inspect registrations, and **Delete** to remove a camp.
5. The dashboard also shows camp statistics, attendee registrations, and an editable organization profile. Changes are saved in MongoDB.

Only the organizer who owns a camp can edit or delete it. Registration contact details are returned by the camp detail API only to that camp's owner.

## UI refresh
- The camp finder now uses an interactive OpenStreetMap/Leaflet map with real map tiles, zoom controls, camp pins, popups, and a marker for the current search area.
- Google Maps direction links remain available from camp popups and camp cards.
- The navigation profile icon opens the account workspace. Visitors can update personal details, upload a profile photo, change their password, and see upcoming/past registrations. Organizers can update organization details, view live camp/registration statistics, manage their own camps, export participant CSV files, upload a profile image, and change their password. Account deletion requires the current password and explicit confirmation.
- Map tiles and Leaflet are loaded from public CDNs, so the interactive map requires an internet connection. OpenStreetMap attribution is shown on the map.


## Profile uploads and privacy

- Profile images are stored under `static/uploads/profiles/` using generated filenames. Images are limited to 2 MB and checked for JPG, PNG, or WebP file signatures.
- The `.env` file and MongoDB credentials must stay local and must not be included in a shared ZIP.
- Organizer dashboard, participant details, and participant CSV export are protected by the organizer role and camp ownership checks.
- Account deletion is permanent. For a visitor it removes that user's registrations; for an organizer it also removes camps owned by that organizer and their registrations.


### Recent profile UI updates
- Camp cards now include a visible **Register** action.
- A **Log out** control is available in the top navigation beside the profile button.
- Visitor profiles support an optional private medical-history field saved through the authenticated profile API. Keep this field limited to information you are comfortable storing in the app.
- Visitor and organizer profile details now sit beside a vertical column of four dashboard summary cards on wide screens; the layout stacks responsively on smaller screens.


## Community camp ratings
- Visitors can rate a camp once its scheduled date has passed, provided they registered for it. This registration/date check helps limit ratings to participants; it does not independently verify physical attendance.
- Ratings are 1–5 stars with an optional review of up to 1,000 characters. A participant can update their rating later.
- Public camp cards display the average rating and review count. Ratings are stored in the MongoDB `ratings` collection.
- API: `POST /api/camps/<camp_id>/rating` (visitor token required), `GET /api/camps/<camp_id>/ratings`.


### Marking a camp completed
Organizers can open their profile/workspace and click **Mark as Completed** on a camp card. Confirm the action. Registered participants will then see it under Past Camps and can submit a star rating. The action is limited to camps owned by the signed-in organizer.


## BhashaSaathi assistant

BhashaSaathi is available from the floating chat button. Its Flask endpoint (`POST /api/chat`) supports English, Hinglish, and Hindi; validates message size; answers emergency and registration intents; and looks up upcoming camps from MongoDB. The chat supports quick prompts, microphone input where the browser supports Web Speech, and spoken replies after voice input. Built-in responses work without an AI key.

### Optional Gemini generative replies

To enable Gemini for free-form questions, add these entries to your private `.env` file (never commit or share the key):

```env
GEMINI_API_KEY=your_key_here
GEMINI_MODEL=gemini-2.5-flash
```

Restart Flask after changing `.env`. If the key is missing or Gemini is unavailable, the built-in multilingual assistant remains available. Camp lookups use this app's MongoDB `camps` collection.

BhashaSaathi gives general website and health information, not a diagnosis. It directs emergency questions to 112/108. Do not enter passwords, OTPs, or private medical records into the chat.


### BhashaSaathi location fallback
If the laptop/browser cannot determine GPS location, click the chatbot **Location** button and enter a city/locality when prompted. Then send `camps near me`. The locality is sent to `/api/chat` and matched against camp venue/name/address text; this does not require device GPS.

## In-app notifications

The app stores in-app alerts in MongoDB's `notifications` collection. Notifications are created for camp registration/cancellation, camp detail changes/cancellations, and organizer review alerts. The navbar bell shows unread alerts and supports marking one or all as read.

A one-day camp reminder is generated when a registered user loads their notifications on the day before the camp. This is an in-app reminder, not a background push: for guaranteed delivery at a fixed time, configure a scheduled job/cron endpoint in the deployment environment.

API endpoints (JWT required):
- `GET /api/notifications` — list recent notifications and unread count
- `PATCH /api/notifications/read-all` — mark all as read
- `PATCH /api/notifications/<notification_id>/read` — mark one as read

### UI refresh
The interface now uses a consistent teal healthcare palette, clearer camp cards, softer shadows, more legible spacing, responsive navigation, and a redesigned notification dropdown. The refresh is CSS-based and does not remove the existing map, camp search, registration, profile, organizer, ratings, or BhashaSaathi features.

### Reminder limitation
Camp reminders are generated when a signed-in user loads the notification endpoint on the day before a camp. Since delivery is in-app only, this is not a push notification and is not guaranteed to appear if the user does not open the app that day. For scheduled background generation in a deployment, use a trusted scheduled job and secure it appropriately.
