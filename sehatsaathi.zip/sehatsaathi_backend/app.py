import os, re, math, uuid, csv, io

from datetime import date, datetime, timedelta

from functools import wraps

from flask import Flask, request, jsonify, render_template, g

from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity

from werkzeug.security import generate_password_hash, check_password_hash

from werkzeug.utils import secure_filename

from flask_cors import CORS

from dotenv import load_dotenv

from pymongo import MongoClient, ASCENDING

from pymongo.errors import DuplicateKeyError

from validation import is_valid_email

load_dotenv()

app = Flask(__name__, template_folder="templates", static_folder="static")

app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "change-this-secret-before-deploying")

app.config["JWT_SECRET_KEY"] = os.getenv("JWT_SECRET_KEY", "change-this-jwt-secret-before-deploying")

app.config["JWT_ACCESS_TOKEN_EXPIRES"] = timedelta(hours=12)

app.config["MAX_CONTENT_LENGTH"] = 3 * 1024 * 1024  # multipart overhead; each image is separately limited to 2 MB

JWTManager(app)

CORS(app, resources={r"/api/*": {"origins": os.getenv("CORS_ORIGINS", "*")}})

MONGODB_URI = os.getenv("MONGODB_URI", "").strip()

if not MONGODB_URI:

    raise RuntimeError("MONGODB_URI is missing. Add it to your local .env file.")

client = MongoClient(MONGODB_URI, serverSelectionTimeoutMS=10000)

# Fail early with a clear error if Atlas is unreachable.

client.admin.command("ping")

db = client[os.getenv("MONGODB_DB", "sehatsaathi")]

users = db["users"]

organizations = db["organizations"]

camps = db["camps"]

registrations = db["registrations"]

ratings = db["ratings"]
notifications = db["notifications"]

counters = db["counters"]

users.create_index([("email", ASCENDING)], unique=True)

organizations.create_index([("email", ASCENDING)], unique=True)

# Safely move older organizer accounts from users to organizations at startup.

# Records with a conflicting email or numeric id are left untouched for manual review.

for legacy_org in users.find({"role": "org"}):

    if organizations.find_one({"$or": [{"email": legacy_org.get("email")}, {"id": legacy_org.get("id")}]}):

        continue

    try:

        organizations.insert_one({k: v for k, v in legacy_org.items() if k != "_id"})

        users.delete_one({"_id": legacy_org["_id"]})

    except DuplicateKeyError:

        pass

camps.create_index([("camp_date", ASCENDING), ("camp_time", ASCENDING)])

registrations.create_index([("camp_id", ASCENDING), ("user_id", ASCENDING)], unique=True)

ratings.create_index([("camp_id", ASCENDING), ("user_id", ASCENDING)], unique=True)

print(f"SehatSaathi connected to MongoDB database: {db.name}; signup collections: users, organizations")

SERVICES = ["General check-up", "Eye care", "Dental", "Diabetes", "Women's health", "Blood donation"]

BASE = {"lat": 28.6692, "lng": 77.4538}

def next_id(name):

    return counters.find_one_and_update({"_id": name}, {"$inc": {"seq": 1}}, upsert=True, return_document=True)["seq"]

def fail(message, status=400): return jsonify({"error": message}), status

def as_date(v):

    if isinstance(v, date): return v

    try: return date.fromisoformat(str(v))

    except (TypeError, ValueError): return None

def user_public(u):

    created = u.get("created_at")

    return {

        "id": u["id"], "name": u.get("name", ""), "email": u.get("email", ""),

        "role": u.get("role", "user"), "phone": u.get("phone", ""),

        "org": u.get("organization", ""), "addr": u.get("address", ""),

        "city": u.get("city", ""), "state": u.get("state", ""),

        "description": u.get("organization_description", ""),

        "website": u.get("website", ""), "dob": u.get("date_of_birth", ""),

        "gender": u.get("gender", ""), "medical_history": u.get("medical_history", ""), "photo": u.get("profile_photo", ""),

        "created_at": created.isoformat() if isinstance(created, datetime) else ""

    }

def get_user(uid):

    """Find an account in either role-specific collection (legacy org accounts may be in users)."""

    try:

        account_id = int(uid)

        return organizations.find_one({"id": account_id}) or users.find_one({"id": account_id})

    except (TypeError, ValueError):

        return None

def account_collection(account):

    """Return the collection that actually contains this account."""

    if account.get("role") == "org" and organizations.find_one({"id": account["id"]}):

        return organizations

    return users

def current_user(): return get_user(get_jwt_identity())

def remove_profile_photo(u):

    photo = str(u.get("profile_photo", ""))

    prefix = "/static/uploads/profiles/"

    if photo.startswith(prefix):

        filename = os.path.basename(photo)

        path = os.path.join(app.static_folder, "uploads", "profiles", filename)

        if os.path.isfile(path):

            try: os.remove(path)

            except OSError: pass

def role_required(role):

    def decorator(fn):

        @wraps(fn)

        @jwt_required()

        def wrapped(*args, **kwargs):

            u=current_user()

            if not u: return fail("Account not found.",401)

            if u["role"] != role: return fail("This action requires a %s account." % role,403)

            g.current_user=u

            return fn(*args, **kwargs)

        return wrapped

    return decorator

def distance_km(lat1,lon1,lat2,lon2):

    r=math.pi/180

    a=math.sin((lat2-lat1)*r/2)**2+math.cos(lat1*r)*math.cos(lat2*r)*math.sin((lon2-lon1)*r/2)**2

    return 12742*math.asin(min(1,math.sqrt(a)))

def create_notification(recipient_id, recipient_role, title, message, kind, camp_id=None, dedupe_key=None):
    """Persist an in-app notification. Optional dedupe_key prevents duplicate reminders."""
    if dedupe_key and notifications.find_one({"dedupe_key": dedupe_key}):
        return
    doc = {"recipient_id": recipient_id, "recipient_role": recipient_role,
           "title": str(title)[:160], "message": str(message)[:500], "kind": kind,
           "camp_id": camp_id, "read": False, "created_at": datetime.utcnow()}
    if dedupe_key:
        doc["dedupe_key"] = dedupe_key
    notifications.insert_one(doc)

def notify_camp_participants(camp, title, message, kind):
    for registration in registrations.find({"camp_id": camp["id"]}, {"user_id": 1}):
        create_notification(registration.get("user_id"), "user", title, message, kind, camp["id"])

def camp_public(c, include_registrations=False):

    regs=list(registrations.find({"camp_id":c["id"]}))

    camp_ratings=list(ratings.find({"camp_id":c["id"]}, {"rating":1}))

    rating_count=len(camp_ratings)

    rating_avg=round(sum(int(r.get("rating",0)) for r in camp_ratings)/rating_count, 1) if rating_count else 0

    owner=get_user(c.get("owner_id")) if c.get("owner_id") else None

    out={"id":c["id"],"name":c["name"],"svc":c["service"],"service":c["service"],"venue":c["venue"],"lat":c["latitude"],"lng":c["longitude"],"date":str(c["camp_date"]),"time":c["camp_time"],"cap":c["capacity"],"capacity":c["capacity"],"info":c.get("info", ""),"registered":len(regs),"seats_left":max(0,c["capacity"]-len(regs)),"owner":owner.get("email") if owner else None,"sample":c.get("sample",False),"status":c.get("status", "upcoming"),"rating_avg":rating_avg,"rating_count":rating_count,"payment_type":c.get("payment_type", "free"),"amount":float(c.get("amount", 0) or 0)}

    if include_registrations: out["registrations"]=[registration_public(r) for r in regs]

    return out

def registration_public(r):

    u=get_user(r["user_id"]); created=r.get("created_at",datetime.utcnow())

    return {"id":r["id"],"cid":r["camp_id"],"camp_id":r["camp_id"],"email":u.get("email","") if u else "","name":r["name"],"phone":r["phone"],"at":int(created.timestamp()*1000),"created_at":created.isoformat()+"Z"}

def parse_camp_payload(data, existing=None):

    name=str(data.get("name","")).strip(); service=str(data.get("svc",data.get("service",""))).strip(); venue=str(data.get("venue","")).strip(); d=as_date(data.get("date")); tm=str(data.get("time","09:00")).strip()

    try: cap=int(data.get("cap",data.get("capacity",60)))

    except (TypeError,ValueError): cap=0

    if not name or len(name)>180: return None,"Camp name is required (max 180 characters)."

    if service not in SERVICES: return None,"Choose a valid health service."

    if not venue or len(venue)>255: return None,"Venue is required (max 255 characters)."

    if not d: return None,"Date must be YYYY-MM-DD."

    if not re.fullmatch(r"(?:[01]\d|2[0-3]):[0-5]\d",tm): return None,"Time must be HH:MM."

    if cap<1 or cap>100000: return None,"Capacity must be between 1 and 100000."

    payment_type = str(data.get("payment_type", existing.get("payment_type", "free") if existing else "free")).strip().lower()
    if payment_type not in ("free", "paid"):
        return None, "Choose whether the camp is free or paid."
    try:
        amount = float(data.get("amount", existing.get("amount", 0) if existing else 0) or 0)
    except (TypeError, ValueError):
        return None, "Enter a valid camp fee."
    if not math.isfinite(amount) or amount < 0 or amount > 10000000:
        return None, "Camp fee must be between 0 and 10000000."
    if payment_type == "paid" and amount <= 0:
        return None, "Enter an amount greater than ₹0 for a paid camp."
    if payment_type == "free":
        amount = 0.0

    # Never silently save the default map centre as a camp's real location.
    # New camps must provide coordinates selected by the organizer; edits may
    # keep the previously saved coordinates when no new coordinates are sent.
    old_lat = existing.get("latitude") if existing else None
    old_lng = existing.get("longitude") if existing else None
    lat_raw = data.get("lat", data.get("latitude", old_lat))
    lng_raw = data.get("lng", data.get("longitude", old_lng))
    if lat_raw in (None, "") or lng_raw in (None, ""):
        return None, "Choose the camp's exact location on the map before saving."
    try:
        lat = float(lat_raw)
    except (TypeError, ValueError):
        return None, "Latitude must be numeric."
    try:
        lng = float(lng_raw)
    except (TypeError, ValueError):
        return None, "Longitude must be numeric."
    if not (math.isfinite(lat) and math.isfinite(lng) and -90 <= lat <= 90 and -180 <= lng <= 180):
        return None, "Coordinates are invalid or out of range."

    return {"name":name,"service":service,"venue":venue,"camp_date":d.isoformat(),"camp_time":tm,"capacity":cap,"info":str(data.get("info","")).strip()[:2000],"latitude":lat,"longitude":lng,"payment_type":payment_type,"amount":amount},None

def seed():

    if camps.find_one({"sample":True}): return

    today=date.today(); rows=[("Free Eye Screening","Eye care","Govt. Dispensary, Vaishali",28.6450,77.3410,2,"09:00",60,"Cataract check and vision test"),("Family Health Check-up","General check-up","Community Hall, Raj Nagar",28.6730,77.4390,3,"10:00",80,"BP, sugar, BMI and doctor consultation"),("Blood Donation Drive","Blood donation","Nehru Park, Kavi Nagar",28.6610,77.4300,5,"08:30",100,"Donors aged 18 to 60 welcome"),("Diabetes Screening","Diabetes","Ward Office, Indirapuram",28.6360,77.3690,6,"09:30",70,"Fasting sugar test and diet counselling"),("Mother and Child Care","Women's health","Anganwadi Centre, Loni",28.7520,77.2870,8,"10:00",50,"Antenatal check-up and nutrition advice"),("School Dental Camp","Dental","Sector 23, Sanjay Nagar",28.6840,77.4570,4,"11:00",60,"Check-up and brushing demonstration")]

    for n,s,v,lat,lng,off,t,cap,info in rows:

        camps.insert_one({"id":next_id("camp"),"name":n,"service":s,"venue":v,"latitude":lat,"longitude":lng,"camp_date":(today+timedelta(days=off)).isoformat(),"camp_time":t,"capacity":cap,"info":info,"sample":True,"owner_id":None,"created_at":datetime.utcnow()})

@app.get("/")

def index(): return render_template("index.html")

@app.get("/api/health")

def health(): return jsonify({"status":"ok","service":"SehatSaathi API","database":"mongodb"})

@app.get("/api/services")

def services_list(): return jsonify({"services":SERVICES})

@app.post("/api/auth/signup")

def signup():

    d=request.get_json(silent=True) or {}; name=str(d.get("name","")).strip(); email=str(d.get("email","")).strip().lower(); password=str(d.get("password","")); role=str(d.get("role","user")); phone=str(d.get("phone","")).strip(); org=str(d.get("org",d.get("organization",""))).strip()

    if not name or len(name)>120: return fail("Enter a valid full name.")

    if not is_valid_email(email): return fail("Enter a valid email.")

    if len(password)<8: return fail("Password must contain at least 8 characters.")

    if role not in ("user","org"): return fail("Role must be user or org.")

    if not re.fullmatch(r"[0-9+ ()-]{10,24}",phone): return fail("Enter a valid phone number.")

    if role=="org" and not org: return fail("Organization name is required for organizers.")

    # Check normalized emails across both collections. This catches legacy records

    # with uppercase letters or accidental surrounding whitespace, not just exact matches.

    def email_exists(collection):

        return collection.find_one({"$expr": {"$eq": [

            {"$toLower": {"$trim": {"input": {"$ifNull": ["$email", ""]}}}}, email

        ]}}, {"_id": 1}) is not None

    existing_user = email_exists(users)

    existing_org = email_exists(organizations)

    if existing_user or existing_org:

        # Log only collection names, never the submitted email or password.

        print(f"Signup blocked: normalized email match in users={existing_user}, organizations={existing_org}")

        return fail("This email is already registered. If it is genuinely new, restart the backend from the updated project folder and check the Flask terminal for the signup diagnostic.", 409)

    u={"id":next_id("user"),"name":name,"email":email,"password_hash":generate_password_hash(password),"role":role,"phone":phone,"organization":org,"address":"","city":"","state":"","organization_description":"","website":"","date_of_birth":"","gender":"","medical_history":"","profile_photo":"","created_at":datetime.utcnow()}

    target = organizations if role == "org" else users

    try:

        target.insert_one(u)

    except DuplicateKeyError:

        # Could be a race between two simultaneous signup requests or a stale unique index.

        print(f"Signup insert duplicate-key error in collection={target.name}; email indexes should be checked")

        return fail("Signup was blocked by a MongoDB unique-index conflict. Check the Flask terminal and the email indexes in both collections.", 409)

    token=create_access_token(identity=str(u["id"]),additional_claims={"role":role})

    return jsonify({"access_token":token,"user":user_public(u)}),201

@app.post("/api/auth/login")

def login():

    d=request.get_json(silent=True) or {}; email=str(d.get("email"," ")).strip().lower(); u=organizations.find_one({"email":email}) or users.find_one({"email":email}); password=str(d.get("password",""))

    if not u or not check_password_hash(u["password_hash"],password): return fail("Email or password is incorrect.",401)

    return jsonify({"access_token":create_access_token(identity=str(u["id"]),additional_claims={"role":u["role"]}),"user":user_public(u)})

@app.get("/api/auth/me")

@jwt_required()

def me():

    u=current_user(); return (jsonify({"user":user_public(u)}),200) if u else fail("Account not found.",401)

@app.get("/api/profile")

@jwt_required()

def get_profile():

    u = current_user()

    return jsonify({"user": user_public(u)}) if u else fail("Account not found.", 401)

@app.put("/api/profile")

@jwt_required()

def update_profile():

    u = current_user()

    if not u: return fail("Account not found.", 401)

    d = request.get_json(silent=True) or {}

    changes = {}

    common = {"name": ("name", 120), "phone": ("phone", 24), "addr": ("address", 255),

              "city": ("city", 100), "state": ("state", 100), "dob": ("date_of_birth", 10),

              "gender": ("gender", 40)}

    for key, (attr, maxlen) in common.items():

        if key in d:

            val = str(d[key] or "").strip()

            if len(val) > maxlen: return fail("%s is too long." % key)

            changes[attr] = val

    if u["role"] == "user" and "medical_history" in d:

        medical_history = str(d.get("medical_history") or "").strip()

        if len(medical_history) > 3000: return fail("Medical history must be 3000 characters or fewer.")

        changes["medical_history"] = medical_history

    if u["role"] == "org":

        for key, attr, maxlen in [("org", "organization", 160),

                                  ("description", "organization_description", 1200),

                                  ("website", "website", 250)]:

            if key in d:

                val = str(d[key] or "").strip()

                if len(val) > maxlen: return fail("%s is too long." % key)

                if key == "website" and val and not re.fullmatch(r"https?://[^\s]+", val, re.I):

                    return fail("Website must begin with http:// or https://.")

                changes[attr] = val

    merged = {**u, **changes}

    if not merged.get("name"): return fail("Full name is required.")

    if not re.fullmatch(r"[0-9+ ()-]{10,24}", merged.get("phone", "")): return fail("Enter a valid phone number.")

    if merged["role"] == "org" and not merged.get("organization"): return fail("Organization name is required.")

    if merged.get("date_of_birth"):

        dob = as_date(merged["date_of_birth"])

        if not dob or dob > date.today(): return fail("Enter a valid date of birth.")

    account_collection(u).update_one({"id": u["id"]}, {"$set": changes})

    return jsonify({"user": user_public(merged)})

@app.put("/api/profile/password")

@jwt_required()

def change_password():

    u = current_user()

    if not u: return fail("Account not found.", 401)

    d = request.get_json(silent=True) or {}

    current = str(d.get("current_password", ""))

    new = str(d.get("new_password", ""))

    if not check_password_hash(u["password_hash"], current): return fail("Current password is incorrect.", 400)

    if len(new) < 8 or len(new) > 128: return fail("New password must contain 8 to 128 characters.")

    account_collection(u).update_one({"id": u["id"]}, {"$set": {"password_hash": generate_password_hash(new)}})

    return jsonify({"message": "Password changed successfully."})

@app.delete("/api/profile")

@jwt_required()

def delete_profile():

    u = current_user()

    if not u: return fail("Account not found.", 401)

    d = request.get_json(silent=True) or {}

    if not check_password_hash(u["password_hash"], str(d.get("password", ""))):

        return fail("Password is incorrect. Account was not deleted.", 400)

    if u["role"] == "org":

        owned = [c["id"] for c in camps.find({"owner_id": u["id"]}, {"id": 1})]

        if owned:

            registrations.delete_many({"camp_id": {"$in": owned}})

            camps.delete_many({"owner_id": u["id"]})

    registrations.delete_many({"user_id": u["id"]})

    ratings.delete_many({"user_id": u["id"]})

    remove_profile_photo(u)

    account_collection(u).delete_one({"id": u["id"]})

    return jsonify({"message": "Account and associated records deleted."})

@app.post("/api/profile/photo")

@jwt_required()

def upload_profile_photo():

    u = current_user()

    if not u: return fail("Account not found.", 401)

    file = request.files.get("photo")

    if not file or not file.filename: return fail("Choose an image to upload.")

    original = secure_filename(file.filename)

    ext = os.path.splitext(original)[1].lower()

    data = file.read(2 * 1024 * 1024 + 1)

    if len(data) > 2 * 1024 * 1024: return fail("Image must be 2 MB or smaller.")

    signatures = {".jpg": data.startswith(b"\xff\xd8\xff"), ".jpeg": data.startswith(b"\xff\xd8\xff"),

                  ".png": data.startswith(b"\x89PNG\r\n\x1a\n"),

                  ".webp": len(data) > 12 and data[:4] == b"RIFF" and data[8:12] == b"WEBP"}

    if ext not in signatures or not signatures[ext]: return fail("Upload a valid JPG, PNG, or WebP image.")

    folder = os.path.join(app.static_folder, "uploads", "profiles")

    os.makedirs(folder, exist_ok=True)

    filename = "%s%s" % (uuid.uuid4().hex, ext)

    with open(os.path.join(folder, filename), "wb") as out: out.write(data)

    photo_url = "/static/uploads/profiles/" + filename

    remove_profile_photo(u)

    account_collection(u).update_one({"id": u["id"]}, {"$set": {"profile_photo": photo_url}})

    return jsonify({"photo": photo_url})

@app.get("/api/camps")

def camps_list():

    q=str(request.args.get("q","")).strip().lower(); service=request.args.get("service",request.args.get("svc"," ")).strip(); from_date=request.args.get("date","").strip()

    if service and service not in SERVICES: return fail("Unknown service.")

    min_date=None

    if from_date:

        min_date=as_date(from_date)

        if not min_date: return fail("date must be YYYY-MM-DD.")

    query={}

    if service: query["service"]=service

    if min_date: query["camp_date"]={"$gte":min_date.isoformat()}

    items=[]

    for c in camps.find(query):

        if q and not any(q in str(c.get(k," ")).lower() for k in ("name","venue","service","info")): continue

        items.append(camp_public(c))

    try: lat=float(request.args.get("lat",BASE["lat"])); lng=float(request.args.get("lng",BASE["lng"]))

    except ValueError: return fail("lat and lng must be numeric.")

    for item in items: item["distance_km"]=round(distance_km(lat,lng,item["lat"],item["lng"]),2)

    items.sort(key=lambda x:(x["distance_km"],x["date"],x["time"]))

    return jsonify({"camps":items,"count":len(items),"services":SERVICES})

@app.get("/api/camps/<int:camp_id>")

@jwt_required(optional=True)

def camp_detail(camp_id):

    c=camps.find_one({"id":camp_id})

    if not c: return fail("Camp not found.",404)

    # Registration contact details are private: only this camp's organizer can view them.

    u=current_user() if get_jwt_identity() else None

    can_view_registrations=bool(u and u.get("role")=="org" and c.get("owner_id")==u.get("id"))

    return jsonify({"camp":camp_public(c,can_view_registrations)})

@app.post("/api/camps")

@role_required("org")

def create_camp():

    values,error=parse_camp_payload(request.get_json(silent=True) or {})

    if error: return fail(error)

    values.update({"id":next_id("camp"),"owner_id":g.current_user["id"],"sample":False,"created_at":datetime.utcnow()}); camps.insert_one(values)

    return jsonify({"camp":camp_public(values)}),201

@app.put("/api/camps/<int:camp_id>")

@role_required("org")

def update_camp(camp_id):

    c=camps.find_one({"id":camp_id})

    if not c: return fail("Camp not found.",404)

    if c.get("sample") or c.get("owner_id")!=g.current_user["id"]: return fail("You can only edit camps created by your account.",403)

    values,error=parse_camp_payload(request.get_json(silent=True) or {},c)

    if error: return fail(error)

    if values["capacity"]<registrations.count_documents({"camp_id":camp_id}): return fail("Capacity cannot be lower than current registrations.")

    old_values = {k: c.get(k) for k in ("name", "camp_date", "camp_time", "venue", "payment_type", "amount")}
    camps.update_one({"id":camp_id},{"$set":values}); c.update(values)
    changed = any(old_values.get(k) != values.get(k) for k in old_values)
    if changed:
        notify_camp_participants(c, "Health camp updated", f"{c.get('name','A health camp')} has updated details. Please check the camp page for the latest information.", "camp_updated")
    return jsonify({"camp":camp_public(c)})

@app.post("/api/camps/<int:camp_id>/complete")

@role_required("org")

def complete_camp(camp_id):

    c = camps.find_one({"id": camp_id})

    if not c:

        return fail("Camp not found.", 404)

    if c.get("sample") or c.get("owner_id") != g.current_user["id"]:

        return fail("You can only complete camps created by your account.", 403)

    if c.get("status") == "completed":

        return jsonify({"message": "Camp is already marked as completed.", "camp": camp_public(c)})

    camps.update_one({"id": camp_id}, {"$set": {"status": "completed", "completed_at": datetime.utcnow()}})

    c["status"] = "completed"

    return jsonify({"message": "Camp marked as completed. Registered participants can now submit ratings.", "camp": camp_public(c)})

@app.delete("/api/camps/<int:camp_id>")

@role_required("org")

def delete_camp(camp_id):

    c=camps.find_one({"id":camp_id})

    if not c: return fail("Camp not found.",404)

    if c.get("sample") or c.get("owner_id")!=g.current_user["id"]: return fail("You can only delete camps created by your account.",403)

    notify_camp_participants(c, "Health camp cancelled", f"{c.get('name','A health camp')} has been cancelled by its organizer.", "camp_cancelled")
    camps.delete_one({"id":camp_id}); registrations.delete_many({"camp_id":camp_id}); ratings.delete_many({"camp_id":camp_id}); return jsonify({"message":"Camp cancelled and removed; registered participants were notified."})

@app.get("/api/registrations")

@jwt_required()

def my_registrations():

    u=current_user()

    if not u: return fail("Account not found.",401)

    if u["role"]=="org":

        own=list(camps.find({"owner_id":u["id"]})); rows=[r for c in own for r in registrations.find({"camp_id":c["id"]})]

    else: rows=list(registrations.find({"user_id":u["id"]}))

    out=[]

    for r in rows:

        c=camps.find_one({"id":r["camp_id"]})

        row={**registration_public(r),"camp":camp_public(c) if c else None}

        if u["role"] == "user":

            existing_rating=ratings.find_one({"camp_id":r["camp_id"],"user_id":u["id"]})

            row["my_rating"]={"rating":existing_rating.get("rating"),"review":existing_rating.get("review","")} if existing_rating else None

        out.append(row)

    return jsonify({"registrations":out})

@app.post("/api/camps/<int:camp_id>/registrations")

@role_required("user")

def register(camp_id):

    u=g.current_user; c=camps.find_one({"id":camp_id})

    if not c: return fail("Camp not found.",404)

    if as_date(c["camp_date"])<date.today(): return fail("Registration for this camp is closed.")

    if registrations.count_documents({"camp_id":camp_id})>=c["capacity"]: return fail("This camp is full.",409)

    d=request.get_json(silent=True) or {}; name=str(d.get("name",u["name"])).strip(); phone=str(d.get("phone",u["phone"])).strip()

    if not name or not re.fullmatch(r"[0-9+ ()-]{10,24}",phone): return fail("Enter a valid name and phone number.")

    r={"id":next_id("registration"),"camp_id":camp_id,"user_id":u["id"],"name":name,"phone":phone,"created_at":datetime.utcnow()}

    try: registrations.insert_one(r)

    except DuplicateKeyError: return fail("You are already registered for this camp.",409)
    create_notification(u["id"], "user", "Registration confirmed", f"You are registered for {c.get('name','the health camp')}.", "registration_confirmed", camp_id)
    owner_id = c.get("owner_id")
    if owner_id is not None:
        create_notification(owner_id, "org", "New camp registration", f"{u.get('name','A participant')} registered for {c.get('name','your camp')}.", "new_registration", camp_id)
    return jsonify({"registration":registration_public(r),"message":"Registration confirmed."}),201

@app.post("/api/camps/<int:camp_id>/rating")

@role_required("user")

def rate_camp(camp_id):

    u=g.current_user

    c=camps.find_one({"id":camp_id})

    if not c: return fail("Camp not found.",404)

    camp_date=as_date(c.get("camp_date"))

    if c.get("status") != "completed" and (not camp_date or camp_date >= date.today()):

        return fail("You can rate this camp after the organizer marks it completed.",400)

    if not registrations.find_one({"camp_id":camp_id,"user_id":u["id"]}):

        return fail("Only registered participants can rate this camp.",403)

    d=request.get_json(silent=True) or {}

    try: score=int(d.get("rating",0))

    except (TypeError,ValueError): score=0

    if score < 1 or score > 5: return fail("Choose a rating from 1 to 5 stars.")

    review=str(d.get("review","")).strip()

    if len(review)>1000: return fail("Review must be 1000 characters or fewer.")

    now=datetime.utcnow()

    ratings.update_one({"camp_id":camp_id,"user_id":u["id"]},{"$set":{"camp_id":camp_id,"user_id":u["id"],"rating":score,"review":review,"updated_at":now},"$setOnInsert":{"created_at":now}},upsert=True)
    if c.get("owner_id") is not None:
        create_notification(c["owner_id"], "org", "New camp review", f"A participant rated {c.get('name','your camp')} {score}/5 stars.", "new_review", camp_id)

    result=list(ratings.find({"camp_id":camp_id},{"rating":1}))

    count=len(result); average=round(sum(int(x.get("rating",0)) for x in result)/count,1) if count else 0

    return jsonify({"message":"Thanks for sharing your camp feedback!","my_rating":{"rating":score,"review":review},"rating_avg":average,"rating_count":count})

@app.get("/api/camps/<int:camp_id>/ratings")

def camp_ratings(camp_id):

    c=camps.find_one({"id":camp_id})

    if not c: return fail("Camp not found.",404)

    rows=list(ratings.find({"camp_id":camp_id}).sort([("updated_at",-1)]).limit(100))

    summary=camp_public(c)

    return jsonify({"rating_avg":summary["rating_avg"],"rating_count":summary["rating_count"],"ratings":[{"rating":r.get("rating",0),"review":r.get("review",""),"created_at":r.get("created_at",datetime.utcnow()).isoformat()+"Z"} for r in rows]})

@app.delete("/api/registrations/<int:registration_id>")

@jwt_required()

def cancel_registration(registration_id):

    u=current_user(); r=registrations.find_one({"id":registration_id})

    if not r: return fail("Registration not found.",404)

    c=camps.find_one({"id":r["camp_id"]})

    if r["user_id"]!=u["id"] and not (u["role"]=="org" and c and c.get("owner_id")==u["id"]): return fail("You cannot cancel this registration.",403)

    registrations.delete_one({"id":registration_id})
    create_notification(r.get("user_id"), "user", "Registration cancelled", f"Your registration for {c.get('name','the health camp') if c else 'the health camp'} was cancelled.", "registration_cancelled", r.get("camp_id"))
    if c and c.get("owner_id") is not None:
        create_notification(c["owner_id"], "org", "Registration cancelled", f"A participant cancelled their registration for {c.get('name','your camp')}.", "registration_cancelled", c.get("id"))
    return jsonify({"message":"Registration cancelled."})

@app.get("/api/notifications")
@jwt_required()
def list_notifications():
    u = current_user()
    if not u:
        return fail("Account not found.", 401)
    # Create one reminder per registration/camp when the camp is tomorrow.
    if u.get("role") == "user":
        tomorrow = (date.today() + timedelta(days=1)).isoformat()
        for reg in registrations.find({"user_id": u["id"]}):
            camp = camps.find_one({"id": reg.get("camp_id")})
            if camp and camp.get("camp_date") == tomorrow and camp.get("status") not in ("completed", "cancelled"):
                create_notification(u["id"], "user", "Health camp tomorrow", f"Reminder: {camp.get('name','Your health camp')} is scheduled for tomorrow.", "camp_reminder", camp.get("id"), f"reminder:{u['id']}:{camp['id']}:{tomorrow}")
    rows = list(notifications.find({"recipient_id": u["id"], "recipient_role": u.get("role")}).sort("created_at", -1).limit(50))
    return jsonify({"notifications": [{"id": str(n["_id"]), "title": n.get("title", "SehatSaathi update"), "message": n.get("message", ""), "kind": n.get("kind", "info"), "camp_id": n.get("camp_id"), "read": bool(n.get("read")), "created_at": n.get("created_at", datetime.utcnow()).isoformat() + "Z"} for n in rows], "unread_count": sum(1 for n in rows if not n.get("read"))})

@app.patch("/api/notifications/read-all")
@jwt_required()
def mark_all_notifications_read():
    u = current_user()
    if not u:
        return fail("Account not found.", 401)
    notifications.update_many({"recipient_id": u["id"], "recipient_role": u.get("role"), "read": False}, {"$set": {"read": True}})
    return jsonify({"message": "All notifications marked as read."})

@app.patch("/api/notifications/<notification_id>/read")
@jwt_required()
def mark_notification_read(notification_id):
    from bson import ObjectId
    u = current_user()
    if not u:
        return fail("Account not found.", 401)
    try:
        oid = ObjectId(notification_id)
    except Exception:
        return fail("Notification not found.", 404)
    result = notifications.update_one({"_id": oid, "recipient_id": u["id"], "recipient_role": u.get("role")}, {"$set": {"read": True}})
    if not result.matched_count:
        return fail("Notification not found.", 404)
    return jsonify({"message": "Notification marked as read."})

@app.get("/api/organizer/dashboard")

@role_required("org")

def organizer_dashboard():

    u=g.current_user; own=list(camps.find({"owner_id":u["id"]}).sort([("camp_date",ASCENDING)])); regs=[r for c in own for r in registrations.find({"camp_id":c["id"]})]; today=date.today()

    return jsonify({"camps":[camp_public(c,True) for c in own],"registrations":[{**registration_public(r),"camp_name":(camps.find_one({"id":r["camp_id"]}) or {}).get("name","")} for r in regs],"stats":{"total_camps":len(own),"upcoming_camps":sum(c.get("status") != "completed" and as_date(c["camp_date"])>=today for c in own),"completed_camps":sum(c.get("status") == "completed" or as_date(c["camp_date"])<today for c in own),"total_registrations":len(regs),"todays_camps":sum(as_date(c["camp_date"])==today for c in own)}})

@app.get("/api/organizer/camps/<int:camp_id>/participants.csv")

@role_required("org")

def export_camp_participants(camp_id):

    c = camps.find_one({"id": camp_id, "owner_id": g.current_user["id"], "sample": {"$ne": True}})

    if not c: return fail("Camp not found or not owned by this account.", 404)

    output = io.StringIO()

    writer = csv.writer(output)

    writer.writerow(["Participant name", "Phone", "Email", "Registration date"])

    def safe_cell(value):

        value = str(value or "")

        return "'" + value if value[:1] in ("=", "+", "-", "@", "\t", "\r") else value

    for r in registrations.find({"camp_id": camp_id}).sort([("created_at", ASCENDING)]):

        u = get_user(r.get("user_id"))

        created = r.get("created_at")

        writer.writerow([safe_cell(r.get("name", "")), safe_cell(r.get("phone", "")),

                         safe_cell(u.get("email", "") if u else ""),

                         created.isoformat() if isinstance(created, datetime) else ""])

    from flask import Response

    return Response(output.getvalue(), mimetype="text/csv",

                    headers={"Content-Disposition": 'attachment; filename="camp-%s-participants.csv"' % camp_id})

def gemini_personalize_suggestions(age, gender, checked, suggestions, other_symptoms=""):

    """Use Gemini to rank existing rule-based recommendations; never let it invent camps.

    Only age, broad gender selection, selected condition codes, optional user-entered

    health concern, and already-found service/camp summaries are sent. If Gemini is

    not configured or fails, the normal database-backed rules continue to work.

    """

    key = os.getenv("GEMINI_API_KEY", "").strip()

    if not key or not suggestions:

        return suggestions, False

    import json as _json

    import urllib.request as _urlrequest

    model = os.getenv("GEMINI_MODEL", "gemini-2.5-flash").strip() or "gemini-2.5-flash"

    safe_options = [{

        "service": item["service"],

        "reasons": item["reasons"],

        "camps": [{"id": camp.get("id"), "name": camp.get("name"),

                   "venue": camp.get("venue"), "date": camp.get("date"),

                   "time": camp.get("time")} for camp in item["camps"]]

    } for item in suggestions]

    prompt = (

        "You personalize community health-camp discovery for SehatSaathi. This is not a diagnosis. "

        "Use only the service options provided; never invent camps, dates, venues, medical facts, or services. "

        "Rank the provided services by relevance to the user's selected profile and return valid JSON only, "

        'with schema {"order":[{"service":"exact provided service name","reasons":["short plain-language reason"]}]}. '

        "Include each provided service at most once. Reasons must be cautious, non-diagnostic, max 160 characters, "

        "and should not claim that a camp treats a condition. Do not recommend blood donation as medical care. "

        "If there is not enough information, preserve the provided rule-based order.\n"

        + "User selection: " + _json.dumps({"age": age, "gender": gender, "selected_codes": sorted(checked), "other_health_concern": other_symptoms}, ensure_ascii=False) + "\n"

        + "Treat free text only as context for ranking. Do not diagnose, infer a disease, or suggest that a listed camp treats it.\n"

        + "Verified database-backed options: " + _json.dumps(safe_options, ensure_ascii=False)

    )

    payload = _json.dumps({

        "contents": [{"parts": [{"text": prompt}]}],

        "generationConfig": {"temperature": 0.1, "maxOutputTokens": 700, "responseMimeType": "application/json"}

    }).encode("utf-8")

    req = _urlrequest.Request(

        "https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent?key=" + key,

        data=payload, headers={"Content-Type": "application/json"}, method="POST")

    try:

        with _urlrequest.urlopen(req, timeout=7) as response:

            data = _json.loads(response.read().decode("utf-8"))

        parts = data.get("candidates", [{}])[0].get("content", {}).get("parts", [])

        raw = "".join(part.get("text", "") for part in parts if part.get("text")).strip()

        parsed = _json.loads(raw)

        by_service = {item["service"]: item for item in suggestions}

        reordered = []

        seen = set()

        for choice in parsed.get("order", []):

            service_name = choice.get("service") if isinstance(choice, dict) else None

            if service_name not in by_service or service_name in seen:

                continue

            item = dict(by_service[service_name])

            reasons = choice.get("reasons", [])

            if isinstance(reasons, list):

                safe_reasons = [str(reason).strip()[:160] for reason in reasons if isinstance(reason, str) and reason.strip()]

                if safe_reasons:

                    item["reasons"] = safe_reasons[:3]

            reordered.append(item)

            seen.add(service_name)

        # Keep any rule-based options Gemini omitted; the model cannot remove all results.

        model_valid = bool(seen)

        reordered.extend(item for item in suggestions if item["service"] not in seen)

        return (reordered or suggestions), model_valid

    except Exception as exc:

        app.logger.warning("AI camp personalization unavailable; using rules: %s", type(exc).__name__)

        return suggestions, False

@app.post("/api/suggestions")

def suggestions():

    d=request.get_json(silent=True) or {}

    try: age=int(d.get("age",0))

    except (TypeError,ValueError): return fail("Age must be a number.")

    if age<1 or age>110: return fail("Enter an age from 1 to 110.")

    conditions = d.get("conditions", []) or []

    symptoms = d.get("symptoms", []) or []

    if not isinstance(conditions, list) or not isinstance(symptoms, list):

        return fail("Conditions and symptoms must be lists.")

    allowed_codes = {"diab", "bp", "heart", "thy", "eyec", "anem", "preg", "vis", "eyep", "tooth", "thirst", "tired", "fever", "head", "joint", "period", "weight", "emer"}

    checked = {str(code) for code in conditions + symptoms if str(code) in allowed_codes}

    gender=d.get("gender","o")

    if gender not in ("f", "m", "o"):

        gender = "o"

    other_symptoms = d.get("other_symptoms", "")

    if not isinstance(other_symptoms, str):

        return fail("Other symptoms must be text.")

    other_symptoms = other_symptoms.strip()[:500]

    if "emer" in checked: return jsonify({"urgent":True,"message":"Chest pain, severe breathlessness or fainting need urgent medical care. Call 112 or ambulance 108; do not wait for a camp.","suggestions":[]})

    scores={}

    def add(s,p,why=""):

        item=scores.setdefault(s,{"score":0,"reasons":[]}); item["score"]+=p

        if why and why not in item["reasons"]: item["reasons"].append(why)

    add("General check-up",1,"a routine check is a good baseline")

    if other_symptoms:

        add("General check-up",2,"you entered an additional health concern; a clinician can help assess it")

    if age<18: add("Dental",2,"regular dental checks matter for children")

    if age>=40: add("Diabetes",2,"sugar screening may be useful from age 40"); add("Eye care",2,"eye checks may be useful from age 40")

    if age>=60: add("General check-up",2,"regular check-ups matter more after 60")

    if gender=="f" and 18<=age<=50: add("Women's health",2,"a routine women's health check")

    rules={"preg":[("Women's health",4,"pregnancy and new-mother care")],"diab":[("Diabetes",4,"you have diabetes"),("Eye care",2,"diabetes can affect the eyes"),("General check-up",1,"")],"bp":[("General check-up",3,"you have high blood pressure")],"heart":[("General check-up",3,"you have a heart condition")],"thy":[("General check-up",2,"you have a thyroid condition")],"eyec":[("Eye care",4,"you have an eye problem")],"anem":[("General check-up",2,"you have anaemia")],"vis":[("Eye care",4,"blurred or poor vision")],"eyep":[("Eye care",3,"eye pain or redness")],"tooth":[("Dental",4,"tooth pain or bleeding gums")],"thirst":[("Diabetes",4,"frequent thirst or urination")],"tired":[("General check-up",2,"constant tiredness"),("Diabetes",1,"")],"fever":[("General check-up",3,"fever or cough")],"head":[("General check-up",2,"headache or dizziness"),("Eye care",1,"")],"joint":[("General check-up",2,"joint or body pain")],"period":[("Women's health",4,"irregular periods or pelvic pain")],"weight":[("Diabetes",2,"unexplained weight change"),("General check-up",1,"")]}

    for k,items in rules.items():

        if k in checked and (k not in ("preg","period") or gender=="f"):

            for it in items: add(*it)

    if gender=="f" and "anem" in checked: add("Women's health",1,"")

    if 18<=age<=60 and not checked.intersection({"diab","bp","heart","thy","anem","preg"}): add("Blood donation",1,"you may be eligible; the camp will check")

    result=[]

    for service,item in sorted(scores.items(),key=lambda kv:kv[1]["score"],reverse=True)[:3]:

        cs=list(camps.find({"service":service,"camp_date":{"$gte":date.today().isoformat()}}).sort([("camp_date",ASCENDING),("camp_time",ASCENDING)]).limit(3))

        result.append({"service":service,"score":item["score"],"reasons":item["reasons"],"camps":[camp_public(c) for c in cs]})

    result, ai_personalized = gemini_personalize_suggestions(age, gender, checked, result, other_symptoms)

    return jsonify({

        "urgent": False,

        "suggestions": result,

        "ai_personalized": ai_personalized,

        "recommendation_source": "gemini" if ai_personalized else "rules",

        "disclaimer": "These suggestions help you find relevant screening services; they are not a diagnosis or treatment plan. Seek a qualified clinician for medical advice. For severe symptoms, call 112/108."

    })

def bhasha_text(lang, en, hn=None, hi=None):

    """Return a localized response for the three interface language options."""

    return {"en": en, "hn": hn or en, "hi": hi or hn or en}.get(lang, en)

def bhasha_try_gemini(message, lang, camp_context):

    """Optional Gemini response; local intent/camp lookup remains available without an API key."""

    key = os.getenv("GEMINI_API_KEY", "").strip()

    if not key:

        return None

    import json as _json

    import urllib.request as _urlrequest

    model = os.getenv("GEMINI_MODEL", "gemini-2.5-flash").strip() or "gemini-2.5-flash"

    language_name = {"en": "English", "hn": "natural Hinglish written in Latin script", "hi": "Hindi in Devanagari"}.get(lang, "English")

    prompt = (

        "You are BhashaSaathi, a friendly assistant for the SehatSaathi community health-camp website in India. "

        "Reply in " + language_name + ". Be concise, accessible and respectful. Help with website navigation, camp services, and general health information. "

        "Never diagnose, prescribe, or claim to replace a clinician. For emergency symptoms, tell the user to call India's emergency number 112 or ambulance 108 immediately. "

        "Only describe camps included in the supplied data; if none fit, say so. Do not ask for passwords, OTPs, or sensitive medical details.\n"

        "Upcoming camp data (may be empty): " + _json.dumps(camp_context, ensure_ascii=False) + "\n"

        "User message: " + message

    )

    payload = _json.dumps({"contents":[{"parts":[{"text":prompt}]}], "generationConfig":{"temperature":0.3,"maxOutputTokens":400}}).encode('utf-8')

    req = _urlrequest.Request(

        "https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent?key=" + key,

        data=payload, headers={"Content-Type":"application/json"}, method="POST")

    try:

        with _urlrequest.urlopen(req, timeout=8) as response:

            data = _json.loads(response.read().decode('utf-8'))

        parts = data.get("candidates", [{}])[0].get("content", {}).get("parts", [])

        answer = " ".join(p.get("text", "") for p in parts if p.get("text"))

        return answer.strip() or None

    except Exception as exc:

        app.logger.warning("BhashaSaathi optional AI provider unavailable: %s", type(exc).__name__)

        return None

@app.post("/api/chat")

def chatbot():

    d = request.get_json(silent=True) or {}

    original = str(d.get("message", "")).strip()

    if not original:

        return fail("Message is required.")

    if len(original) > 1000:

        return fail("Please keep your message under 1000 characters.")

    lang = str(d.get("language", "en")).lower()

    if lang not in ("en", "hn", "hi"):
        lang = "en"

    # Respect the selected language, but detect clearly Hindi/Hinglish messages
    # when the frontend sends its default English value.
    if re.search(r"[\u0900-\u097F]", original):
        lang = "hi"
    elif lang == "en" and re.search(
        r"\b(?:mujhe|mera|meri|mere|kya|kaise|karun|karein|batao|dikhao|hai|hain|bukhar|aankhon|dant|camp kab)\b",
        original.lower()
    ):
        lang = "hn"

    msg = original.lower()
    ai_used = False

    emergency = re.search(r"emergency|ambulance|chest pain|heart attack|can't breathe|cannot breathe|severe breathlessness|saans|सीने में दर्द|छाती में दर्द|सांस नहीं|साँस नहीं|एम्बुलेंस|इमरजेंसी|आपातकाल", msg)

    cancel_registration = bool(re.search(
        r"\b(?:cancel|cancellation|withdraw|remove)\b.{0,70}\b(?:camp\s+)?registration\b|"
        r"\b(?:cancel|withdraw)\b.{0,45}\b(?:my\s+)?booking\b|"
        r"रजिस्ट्रेशन\s*रद्द|पंजीकरण\s*रद्द|बुकिंग\s*रद्द",
        msg
    ))
    rating_request = bool(re.search(
        r"\b(?:rate|rating|review|reviews|stars|give feedback|leave feedback)\b|"
        r"रेटिंग|रेट करें|समीक्षा|फीडबैक|प्रतिक्रिया",
        msg
    ))
    organizer_create = bool(re.search(
        r"\b(?:organizer|organisation|organization|organization account|organizer account)\b.{0,80}\b(?:add|create|post|publish|new)\b.{0,35}\bcamp\b|"
        r"\bhow can (?:an? )?(?:organization|organisation|organizer)\b.{0,80}\bcamp\b|"
        r"\badd (?:a )?new camp\b|नया कैंप|नया शिविर",
        msg
    ))
    registration = re.search(r"regist|sign ?up|enroll|book|join camp|panjikaran|रजिस्|पंजीकरण|रजिस्टर|नाम लिख", msg)

    how_it_works = re.search(
        r"\bhow\s+(?:(?:does|do|can|could|should)\s+)?(?:i\s+)?(?:register|cancel|rate|add|create|find|use|navigate|work|join|book)\b|"
        r"kaise|कैसे|कहाँ से|where (?:do|can) i",
        msg
    )

    greetings = re.search(r"^(hi|hello|hey|namaste|namaskar|नमस्ते|नमस्कार|हेलो)[\s!.।]*$", msg)

    service_patterns = {

        "Eye care": r"eye|aankh|आँख|आंख|vision|chashma|दृष्टि|नज़र|नजर",

        "Dental": r"dent|teeth|tooth|dant|दांत|दाँत|दंत|मसूड़े|मसूड़े",

        "Diabetes": r"diabet|sugar|madhumeh|शुगर|मधुमेह|ब्लड शुगर",

        "Blood donation": r"blood donation|donate blood|khoon|रक्तदान|खून देना|रक्त",

        "Women's health": r"women|mother|pregnan|mahila|महिला|गर्भ|मातृत्व|पीरियड|मासिक धर्म",

        "General check-up": r"check.?up|general|jaanch|जांच|जाँच|सामान्य जांच|स्वास्थ्य जांच",

    }

    service = next((name for name, pattern in service_patterns.items() if re.search(pattern, msg)), None)

    # Only explicit, positive camp-search requests should return camp listings.
    # Do not treat words like "upcoming" as a search request when the user says
    # NOT to show camps (for example, "Do not show or list upcoming health camps").
    negative_camp_request = bool(re.search(
        r"\b(?:do not|don't|dont|never|no need to)\b.{0,70}"
        r"\b(?:show|list|display|mention|include)\b.{0,45}"
        r"\b(?:camps?|upcoming health camps?|health camps?)\b",
        msg
    ))
    positive_camp_request = bool(re.search(
        r"\b(?:show|list|find|search for|display|which are|what are|where are)\b.{0,65}"
        r"\b(?:(?:upcoming|nearby|nearest|near me) )?(?:health )?(?:eye |dental |diabetes |blood donation )?camps?\b|"
        r"\b(?:are there|is there)\b.{0,45}\b(?:upcoming )?(?:eye |dental |diabetes |blood donation )?(?:health )?camps?\b|"
        r"\b(?:when|where)\b.{0,45}\b(?:next|upcoming)\b.{0,35}\bcamps?\b|"
        r"\b(?:next|upcoming)\s+(?:health\s+)?camps?\b|"
        r"\b(?:nearby|nearest|upcoming)\s+(?:health\s+)?camps?\b|"
        r"\b(?:camps?|health camps?)\b.{0,45}"
        r"\b(?:nearby|nearest|near me|available|dates?|timings?|next)\b|"
        r"कैंप दिखाएं|कैंप बताएं|कैंप खोजें|आने वाले कैंप|नज़दीकी कैंप|नजदीकी कैंप|शिविर दिखाएं|अगला कैंप|आँखों के कैंप|आंखों के कैंप",
        msg
    ))
    compact_camp_search = bool(re.search(
        r"\b(?:camps?|health camps?)\b.{0,55}\b(?:near\s*m\s*e|near|in|around|close to|nearby)\b|"
        r"\b(?:near|in|around)\s+[a-z][a-z .'-]{1,40}\s+camps?\b", msg
    ))
    asks_camps = (positive_camp_request or compact_camp_search) and not negative_camp_request

    # Handle this common educational question locally so it still works when
    # Gemini is not configured or its API request fails. Do not show camp cards.
    camp_vs_hospital = bool(
        re.search(r"\b(?:health\s*camp|health camps?|camp)\b|स्वास्थ्य कैंप|हेल्थ कैंप", msg)
        and re.search(r"\b(?:hospital|hospitals)\b|अस्पताल", msg)
        and re.search(r"\b(?:difference|different|differ|compare|comparison|cricket|example|explain|explanation)\b|फर्क|अंतर|तुलना|समझाओ|समझाएं", msg)
    )



    query = {"camp_date": {"$gte": date.today().isoformat()}, "status": {"$nin": ["completed", "cancelled"]}}

    if service:

        query["service"] = service

    # Optional location terms are matched against camp venue/name/city without requiring a new database field.

    # Extract a locality without accidentally swallowing trailing words such as
    # "camps", "please", or "show" (e.g. "camps near Seelampur please").
    location_match = re.search(
        r"(?:\bnear\b|\bin\b|\bat\b|पास|में|नजदीक|नज़दीक)\s+([a-zA-Z][a-zA-Z .'-]{1,50})",
        original, re.I
    )
    location = location_match.group(1).strip(" .?!,") if location_match else ""
    location = re.sub(
        r"\s+(?:health\s+)?camps?(?:\s+(?:please|nearby|available|dikhao|batao|show|list))?\s*$",
        "", location, flags=re.I
    ).strip(" .?!,")
    location = re.sub(r"\s+(?:please|pls|dikhao|batao|show|list)$", "", location, flags=re.I).strip()
    # A user may provide a locality manually when the device/browser cannot
    # determine GPS. Prefer the explicit field, validated as a short text value.
    supplied_location = str(d.get("location", "")).strip()[:100]
    if supplied_location:
        location = supplied_location
    # "near me" is not a literal locality. It must be resolved from browser
    # coordinates or clarified with the user.
    if location.lower() in {"me", "my area", "my location", "here"}:
        location = ""

    raw_camps = list(camps.find(query).sort([("camp_date", ASCENDING), ("camp_time", ASCENDING)]).limit(30))

    # If the website sends browser coordinates, rank nearby camps by distance.
    # Without coordinates, do not pretend that date-sorted camps are the nearest.
    nearby_request = bool(re.search(r"\b(?:nearby|nearest|near\s*m\s*e|close to me)\b|नज़दीकी|नजदीकी", msg))
    user_lat = user_lng = None
    try:
        lat_value = d.get("latitude", d.get("lat"))
        lng_value = d.get("longitude", d.get("lng"))
        if lat_value not in (None, "") and lng_value not in (None, ""):
            candidate_lat, candidate_lng = float(lat_value), float(lng_value)
            if math.isfinite(candidate_lat) and math.isfinite(candidate_lng) and -90 <= candidate_lat <= 90 and -180 <= candidate_lng <= 180:
                user_lat, user_lng = candidate_lat, candidate_lng
                raw_camps.sort(key=lambda c: distance_km(user_lat, user_lng, float(c.get("latitude", BASE["lat"])), float(c.get("longitude", BASE["lng"]))))
    except (TypeError, ValueError):
        user_lat = user_lng = None

    if location:

        def normalized_location(value):
            value = str(value or "").lower()
            value = re.sub(r"[^a-z0-9\s]", " ", value)
            return re.sub(r"\s+", " ", value).strip()

        wanted = normalized_location(location)
        tokens = [t for t in wanted.split() if len(t) > 2]
        matched = []
        for camp in raw_camps:
            fields = normalized_location(" ".join(
                str(camp.get(k, "")) for k in ("venue", "name", "city", "address", "location")
            ))
            # Prefer the full locality phrase. For multiword localities, require
            # every meaningful word to match so one incidental word cannot pull
            # in unrelated camps.
            if wanted and (wanted in fields or (tokens and all(t in fields for t in tokens))):
                matched.append(camp)
        # Locality is a strict filter: never claim unrelated camps match.
        raw_camps = matched

    raw_camps = raw_camps[:3]

    camp_context = [{"name": c.get("name", "Health camp"), "service": c.get("service", ""), "venue": c.get("venue", c.get("address", "Location to be confirmed")), "date": str(c.get("camp_date", "")), "time": str(c.get("camp_time", ""))} for c in raw_camps]

    if camp_vs_hospital:

        answer = bhasha_text(lang,
            "Hey! 😊 A health camp and a hospital are both important, but they do different jobs. Cricket example se samjho:\n\n"
            "1. **Health camp = practice session 🏏** — Basic screening hoti hai, jaise BP, sugar ya eye check. Isse health issue ka early signal mil sakta hai.\n\n"
            "2. **Hospital = full team aur stadium 🏥** — Yahan doctors and specialists detailed tests, emergency care, surgery aur treatment de sakte hain.\n\n"
            "3. **Camp = early check; hospital = detailed care 🩺** — Camp problem ka signal de sakta hai; zaroorat pade to doctor hospital refer kar sakte hain.\n\n"
            "Simple takeaway: camp screening aur awareness ke liye, hospital diagnosis aur treatment ke liye. 💚",
            "Health camp aur hospital dono important hain. Cricket example se samjho:\n\n"
            "1. **Health camp = practice session 🏏** — Yahan BP, sugar ya aankhon ka basic check hota hai.\n\n"
            "2. **Hospital = poori team aur stadium 🏥** — Yahan specialists, detailed tests, emergency care, surgery aur treatment mil sakta hai.\n\n"
            "3. **Camp = early check; hospital = detailed care 🩺** — Camp mein problem ka signal mil sakta hai; zaroorat par doctor hospital bhej sakte hain.\n\n"
            "Seedhi baat: camp screening ke liye, hospital diagnosis aur treatment ke liye. 💚",
            "स्वास्थ्य कैंप और अस्पताल दोनों ज़रूरी हैं। क्रिकेट के उदाहरण से समझिए:\n\n"
            "1. **स्वास्थ्य कैंप = प्रैक्टिस सेशन 🏏** — यहाँ BP, शुगर या आँखों की शुरुआती जाँच होती है।\n\n"
            "2. **अस्पताल = पूरी टीम और स्टेडियम 🏥** — यहाँ विशेषज्ञ, विस्तृत जाँच, इमरजेंसी देखभाल, सर्जरी और इलाज मिल सकता है।\n\n"
            "3. **कैंप = शुरुआती जाँच; अस्पताल = विस्तृत इलाज 🩺** — कैंप में समस्या का संकेत मिल सकता है; ज़रूरत पड़ने पर डॉक्टर अस्पताल भेज सकते हैं।\n\n"
            "सीधी बात: कैंप शुरुआती जाँच और जागरूकता के लिए, अस्पताल बीमारी की जाँच और इलाज के लिए। 💚")

    elif emergency:

        answer = bhasha_text(lang,

            "This may be a medical emergency. Call 112 or ambulance 108 now. Do not wait for a health camp or a chat reply.",

            "Yeh medical emergency ho sakti hai. Abhi 112 ya ambulance 108 par call karein. Camp ya chat ka intezar na karein.",

            "यह मेडिकल इमरजेंसी हो सकती है। अभी 112 या एम्बुलेंस 108 पर कॉल करें। कैंप या चैट के जवाब का इंतज़ार न करें।")

    elif cancel_registration:

        answer = bhasha_text(lang,
            "To cancel a camp registration, sign in, open your profile or My Registrations section, find the camp, and select Cancel if that option is available. If you cannot see the option, contact the camp organizer. Cancellation availability may depend on your website's current settings.",
            "Camp registration cancel karne ke liye login karein, Profile ya My Registrations section kholein, camp dhoondein aur Cancel option ho to use select karein. Option na mile to camp organizer se contact karein. Cancellation aapki website ki settings par depend kar sakti hai.",
            "कैंप का रजिस्ट्रेशन रद्द करने के लिए लॉग इन करें, Profile या My Registrations खोलें, कैंप ढूँढें और Cancel विकल्प उपलब्ध हो तो चुनें। विकल्प न मिले तो कैंप आयोजक से संपर्क करें। रद्द करने की सुविधा वेबसाइट की सेटिंग पर निर्भर हो सकती है।")

    elif rating_request:

        answer = bhasha_text(lang,
            "To rate a camp, sign in with the same account you used to register, open the completed camp, and look for Rate Camp or Reviews. If the star selector is not visible, the organizer may need to mark the camp as completed first, and your account may need to have a registration for that camp.",
            "Camp ko rate karne ke liye usi account se login karein jisse register kiya tha. Completed camp kholein aur Rate Camp ya Reviews option dekhein. Stars na dikhein to organizer ko pehle camp completed mark karna ho sakta hai; rating ke liye us camp mein registration bhi zaroori ho sakta hai.",
            "कैंप को रेट करने के लिए उसी अकाउंट से लॉग इन करें जिससे आपने रजिस्ट्रेशन किया था। पूरा हुआ कैंप खोलें और Rate Camp या Reviews विकल्प देखें। स्टार न दिखें तो आयोजक को पहले कैंप को Completed मार्क करना पड़ सकता है। उस कैंप में आपका रजिस्ट्रेशन भी होना चाहिए।")

    elif organizer_create:

        answer = bhasha_text(lang,
            "To add a camp, sign in with an organizer account, open the organizer dashboard, choose Add/Create Camp, fill in the camp name, service, date, time, venue, and capacity, then save it. Check the Camps list afterward to confirm it appears.",
            "Naya camp add karne ke liye organizer account se login karein, Organizer Dashboard kholein, Add/Create Camp chunein, camp ka naam, service, date, time, venue aur capacity bharein, phir save karein. Baad mein Camps list mein check karein ki camp dikh raha hai.",
            "नया कैंप जोड़ने के लिए Organizer अकाउंट से लॉग इन करें, Organizer Dashboard खोलें, Add/Create Camp चुनें, कैंप का नाम, सेवा, तारीख, समय, स्थान और क्षमता भरकर सेव करें। फिर Camps सूची में जाँचें कि कैंप दिखाई दे रहा है।")

    elif registration:

        answer = bhasha_text(lang,

            "To register, sign in as a user, find an upcoming camp, select Register, and confirm the requested details. If Register is unavailable, the camp may be full or registration may be closed.",

            "Register karne ke liye user account se login karein, upcoming camp kholein, Register dabayein aur details confirm karein. Button na dikhe to registration band ya seats full ho sakti hain.",

            "रजिस्टर करने के लिए यूज़र अकाउंट से लॉग इन करें, आने वाला कैंप खोलें, Register दबाएँ और मांगी गई जानकारी की पुष्टि करें। बटन न दिखे तो रजिस्ट्रेशन बंद या सीटें पूरी हो सकती हैं।")

    elif re.search(r"fever|temperature|bukhar|bukhaar|cough|khansi|headache|pain|dard|बुखार|तापमान|खांसी|खाँसी|सिरदर्द|दर्द", msg):

        slight_fever = bool(re.search(
            r"\b(?:slight|mild|little|low[- ]grade)\s+(?:fever|temperature)\b|"
            r"\b(?:fever|temperature)\b.{0,25}\b(?:slight|mild|little|low)\b|"
            r"\bhalka\s+(?:bukhar|bukhaar)\b|हल्का\s*बुखार|थोड़ा\s*बुखार",
            msg
        ))

        if slight_fever:
            answer = bhasha_text(lang,
                "Sorry you're feeling unwell. If you have a slight fever: (1) Rest and avoid strenuous activity. (2) Drink water and other fluids regularly. (3) Check your temperature with a thermometer and keep track of it. Avoid overheating and wear comfortable, light clothing. If the fever persists for more than a couple of days, gets worse, or you have other concerning symptoms, contact a healthcare professional. Seek urgent care for trouble breathing, confusion, severe weakness, or other severe symptoms. In India, call 112 for an emergency or 108 for an ambulance. I can't diagnose the cause of your fever.",
                "Aapko theek nahi lag raha, sun kar afsos hua. Agar halka bukhar hai: (1) Aaram karein aur zyada mehnat wala kaam na karein. (2) Paani aur doosre fluids regular peete rahein. (3) Thermometer se temperature check karke note karein. Bahut zyada garam kapde na pehnein. Bukhar kuch din tak rahe, badhe, ya doosre pareshan karne wale lakshan hon, toh healthcare professional se baat karein. Saans lene mein dikkat, confusion ya bahut zyada kamzori ho toh urgent medical help lein. India mein emergency ke liye 112 ya ambulance ke liye 108 call karein. Main bukhar ka cause diagnose nahi kar sakta.",
                "आपको अस्वस्थ महसूस हो रहा है, यह सुनकर अफ़सोस है। हल्का बुखार हो तो: (1) आराम करें और ज़्यादा मेहनत वाला काम न करें। (2) पानी और अन्य तरल पदार्थ नियमित रूप से लें। (3) थर्मामीटर से तापमान जाँचकर नोट करें। बहुत गर्म कपड़े न पहनें। बुखार कुछ दिनों तक बना रहे, बढ़े या अन्य चिंताजनक लक्षण हों, तो स्वास्थ्यकर्मी से संपर्क करें। साँस लेने में परेशानी, भ्रम या बहुत अधिक कमज़ोरी हो तो तुरंत चिकित्सा सहायता लें। भारत में आपात स्थिति में 112 या एम्बुलेंस के लिए 108 पर कॉल करें। मैं बुखार का कारण नहीं बता सकता।")
        else:
            answer = bhasha_text(lang,
                "I can't diagnose symptoms. Rest, drink fluids, and monitor how you feel. Seek medical advice if symptoms persist, worsen, or concern you. For trouble breathing, confusion, severe weakness, or another emergency, call 112 or ambulance 108 in India.",
                "Main symptoms ka diagnosis nahi kar sakta. Aaram karein, fluids lete rahein aur apni tabiyat par nazar rakhein. Lakshan bane rahein, badhein ya chinta ho toh doctor se baat karein. Saans lene mein dikkat, confusion ya bahut zyada kamzori ho toh India mein 112 ya ambulance 108 call karein.",
                "मैं लक्षणों का निदान नहीं कर सकता। आराम करें, तरल पदार्थ लेते रहें और अपनी तबीयत पर नज़र रखें। लक्षण बने रहें, बढ़ें या चिंता हो तो डॉक्टर से संपर्क करें। साँस लेने में परेशानी, भ्रम या बहुत अधिक कमज़ोरी हो तो भारत में 112 या एम्बुलेंस 108 पर कॉल करें।")

    elif greetings:

        answer = bhasha_text(lang,

            "Hello! I'm BhashaSaathi. I can help you find upcoming health camps, understand services, or register for a camp. What would you like help with?",

            "Namaste! Main BhashaSaathi hoon. Main upcoming health camps, services aur registration mein madad kar sakta hoon. Aap kya jaanna chahenge?",

            "नमस्ते! मैं भाषासाथी हूँ। मैं आने वाले स्वास्थ्य कैंप, सेवाओं और रजिस्ट्रेशन के बारे में मदद कर सकता हूँ। आप क्या जानना चाहेंगे?")

    elif asks_camps:

        if nearby_request and user_lat is None and user_lng is None and not location:
            answer = bhasha_text(
                lang,
                "I can find nearby camps, but this chat has not received your location. Allow location access using the website's location button, or tell me your city/locality (for example, Vaishali or Raj Nagar). I won't guess your location.",
                "Main nearby camps dhoondh sakta hoon, lekin chat ko aapki location nahi mili. Website ka location button use karein ya apna city/locality batayein (jaise Vaishali ya Raj Nagar). Main aapki location ka andaza nahi lagaunga.",
                "मैं नज़दीकी कैंप खोज सकता हूँ, लेकिन चैट को आपकी लोकेशन नहीं मिली है। वेबसाइट का लोकेशन बटन इस्तेमाल करें या अपना शहर/इलाका बताएँ (जैसे वैशाली या राज नगर)। मैं आपकी लोकेशन का अनुमान नहीं लगाऊँगा।"
            )
        elif raw_camps:

            rows = []

            for c in raw_camps:

                nm = str(c.get("name", "Health camp")); venue = str(c.get("venue", c.get("address", "Location to be confirmed")))

                dt = str(c.get("camp_date", "Date to be confirmed")); tm = str(c.get("camp_time", ""))
                distance_label = ""
                if user_lat is not None and user_lng is not None:
                    try:
                        km = distance_km(user_lat, user_lng, float(c.get("latitude", BASE["lat"])), float(c.get("longitude", BASE["lng"])))
                        distance_label = f" — about {km:.1f} km away"
                    except (TypeError, ValueError):
                        pass
                rows.append(f"• {nm} — {venue}, {dt}" + (f", {tm}" if tm else "") + distance_label)

            prefix = bhasha_text(lang, "Here are matching upcoming camps, ordered by distance where your location is available:", "Yeh matching upcoming camps hain; location milne par distance ke hisaab se order kiye gaye hain:", "ये मिलते-जुलते आने वाले कैंप हैं; आपकी लोकेशन मिलने पर इन्हें दूरी के अनुसार क्रम में रखा गया है:")
            answer = prefix + "\n" + "\n".join(rows)

        else:
            if location:
                answer = bhasha_text(lang,
                    f"I couldn't find any upcoming health camps in {location} right now. Try another locality or ask ‘Show all upcoming health camps’ to see camps in other areas.",
                    f"Abhi {location} mein koi upcoming health camp nahi mila. Aap doosra area try karein, ya ‘Show all upcoming health camps’ poochhein.",
                    f"अभी {location} में कोई आने वाला स्वास्थ्य कैंप नहीं मिला। कोई दूसरा इलाका आज़माएँ या दूसरे क्षेत्रों के कैंप देखने के लिए ‘Show all upcoming health camps’ पूछें।")
            else:
                answer = bhasha_text(lang,
                    "I couldn't find any matching upcoming health camps right now. Try another service or ask ‘Show all upcoming health camps’.",
                    "Abhi is request se milta hua koi upcoming health camp nahi mila. Koi doosri service poochhein ya ‘Show all upcoming health camps’ likhein.",
                    "अभी इस अनुरोध से मेल खाता कोई आने वाला स्वास्थ्य कैंप नहीं मिला। कोई दूसरी सेवा पूछें या ‘Show all upcoming health camps’ लिखें।")

    elif how_it_works:

        answer = bhasha_text(lang,

            "Use the Camps section to browse camps and filter by service or date. Open a camp for its details and directions, then select Register after signing in. Organizers can sign in with an organizer account to create and manage camps.",

            "Camps section mein camps dekhein aur service ya date se filter karein. Details aur directions ke liye camp kholein; login ke baad Register dabayein. Organizer account se camps create aur manage kiye ja sakte hain.",

            "Camps सेक्शन में कैंप देखें और सेवा या तारीख के अनुसार फ़िल्टर करें। विवरण और दिशा देखने के लिए कैंप खोलें; लॉग इन करने के बाद Register चुनें। Organizer अकाउंट से कैंप बनाए और मैनेज किए जा सकते हैं।")

    else:

        # If configured, use Gemini for a natural-language answer grounded in real upcoming camp data.

        answer = bhasha_try_gemini(original, lang, camp_context)
        ai_used = bool(answer)

        if not answer:

            answer = bhasha_text(lang,

                "I can help with SehatSaathi and general health education. For example, ask ‘What is diabetes?’, ‘How is a health camp different from a hospital?’, ‘How do I register?’, or ‘Show eye camps’. I can share general information, but I can't diagnose a condition or prescribe medicines. If you meant a specific question, please rephrase it and I'll try to help.",

                "Main SehatSaathi aur general health jaankari mein madad kar sakta hoon. Jaise poochhein: ‘Diabetes kya hai?’, ‘Health camp aur hospital mein kya farq hai?’, ‘Register kaise karun?’ ya ‘Eye camps dikhao’. Main general jaankari de sakta hoon, diagnosis ya dawa prescribe nahi kar sakta. Apna specific sawal thoda aur saaf likhein, main madad karne ki koshish karunga.",

                "मैं SehatSaathi और स्वास्थ्य से जुड़ी सामान्य जानकारी में मदद कर सकता हूँ। उदाहरण के लिए पूछें: ‘डायबिटीज़ क्या है?’, ‘स्वास्थ्य कैंप और अस्पताल में क्या अंतर है?’, ‘रजिस्ट्रेशन कैसे करें?’ या ‘आँखों के कैंप दिखाएँ’। मैं सामान्य जानकारी दे सकता हूँ, लेकिन बीमारी का निदान या दवा लिखना नहीं कर सकता। अपना सवाल थोड़ा स्पष्ट लिखें, मैं मदद करने की कोशिश करूँगा।")

    return jsonify({
        "reply": answer,
        "language": lang,
        "source": "ai" if ai_used else "sehatsaathi",
        "camp_count": len(raw_camps),
    })

@app.errorhandler(404)

def not_found(e):

    if request.path.startswith("/api/"): return jsonify({"error":"Endpoint not found."}),404

    return e

@app.errorhandler(500)

def server_error(e): return jsonify({"error":"Internal server error."}),500

seed()

if __name__=="__main__": app.run(host=os.getenv("HOST","127.0.0.1"),port=int(os.getenv("PORT","5000")),debug=os.getenv("FLASK_DEBUG","0")=="1")

@app.errorhandler(413)

def too_large(_error):

    return fail("Uploaded file is too large. Maximum size is 2 MB.", 413)
