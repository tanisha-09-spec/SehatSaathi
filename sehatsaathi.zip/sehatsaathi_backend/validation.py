"""Small, database-independent validation helpers for SehatSaathi."""

import re


def is_valid_email(email: str) -> bool:
    """Return whether an email has a basic local@domain.tld structure.

    This intentionally performs practical form validation, not full RFC validation.
    The dot before the domain suffix is literal (``\\.``), not a regex wildcard.
    """
    if not isinstance(email, str):
        return False

    if email != email.strip():
        return False
    if not email or len(email) > 254:
        return False

    # Reject whitespace, missing parts, missing domain suffix, and a trailing dot.
    if not re.fullmatch(r"[^@\s]+@[^@\s.]+(?:\.[^@\s.]+)+", email):
        return False

    local, domain = email.rsplit("@", 1)
    if len(local) > 64 or local.startswith(".") or local.endswith(".") or ".." in local:
        return False

    return all(label and len(label) <= 63 and not label.startswith("-") and not label.endswith("-")
               for label in domain.split("."))
