"""Focused unit tests for input validation; these do not require MongoDB."""
import unittest

from validation import is_valid_email


class EmailValidationTests(unittest.TestCase):
    def test_accepts_normal_email_addresses(self):
        for email in (
            "test@example.com",
            "first.last@example.co.in",
            "user+camp@example.org",
            "TEST@EXAMPLE.COM",
        ):
            with self.subTest(email=email):
                self.assertTrue(is_valid_email(email))

    def test_rejects_malformed_email_addresses(self):
        for email in (
            "",
            "plain-text",
            "test@",
            "@example.com",
            "test@example",
            "test@example.",
            "test..name@example.com",
            " test@example.com ",
            "test name@example.com",
            "test@example..com",
            "test@-example.com",
        ):
            with self.subTest(email=email):
                self.assertFalse(is_valid_email(email))

    def test_rejects_non_string_values(self):
        for value in (None, 123, [], {}):
            with self.subTest(value=value):
                self.assertFalse(is_valid_email(value))


if __name__ == "__main__":
    unittest.main()
