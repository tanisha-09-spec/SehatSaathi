"""Smoke tests against the MongoDB configured in .env. Run only with a test Atlas database."""
import unittest
import uuid
from app import app

class ApiSmokeTests(unittest.TestCase):
    def setUp(self):
        app.config.update(TESTING=True)
        self.client = app.test_client()

    def test_health_and_services(self):
        self.assertEqual(self.client.get('/api/health').status_code, 200)
        self.assertEqual(len(self.client.get('/api/services').json['services']), 6)

    def test_signup_login(self):
        email = f"test-{uuid.uuid4().hex}@example.com"
        data = {"name":"Test Visitor", "email":email, "password":"strong-password-1", "phone":"9876543210", "role":"user"}
        response = self.client.post('/api/auth/signup', json=data)
        self.assertEqual(response.status_code, 201, response.get_json())
        response = self.client.post('/api/auth/login', json={"email":email, "password":data['password']})
        self.assertEqual(response.status_code, 200, response.get_json())
        token = response.get_json()['access_token']
        headers = {"Authorization": f"Bearer {token}"}
        saved = self.client.put('/api/profile', json={"medical_history":"Penicillin allergy"}, headers=headers)
        self.assertEqual(saved.status_code, 200, saved.get_json())
        profile = self.client.get('/api/profile', headers=headers)
        self.assertEqual(profile.get_json()['user']['medical_history'], "Penicillin allergy")

    def test_suggestions_validation(self):
        self.assertEqual(self.client.post('/api/suggestions', json={"age":45,"gender":"f","conditions":[],"symptoms":[]}).status_code, 200)
        other = self.client.post('/api/suggestions', json={"age":45,"gender":"o","conditions":[],"symptoms":[],"other_symptoms":"Occasional back discomfort"})
        self.assertEqual(other.status_code, 200, other.get_json())
        self.assertTrue(any("additional health concern" in reason for item in other.get_json()["suggestions"] for reason in item["reasons"]))
        invalid = self.client.post('/api/suggestions', json={"age":45,"other_symptoms":["not text"]})
        self.assertEqual(invalid.status_code, 400)
        self.assertTrue(self.client.post('/api/suggestions', json={"age":45,"conditions":["emer"],"symptoms":[]}).json['urgent'])

if __name__ == '__main__':
    unittest.main()
